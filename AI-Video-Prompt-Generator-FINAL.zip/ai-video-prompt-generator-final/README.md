# AI Video Prompt Generator

Web app responsive dengan 14 kolom, camera motion bilingual, prompt Indonesia editable, English final locked, dan AI enhancement.

## Deploy Vercel
1. Upload isi folder ini ke GitHub.
2. Import repository ke Vercel.
3. Tambahkan Environment Variables: OPENAI_API_KEY dan OPENAI_MODEL=gpt-5.6.
4. Redeploy dan buka URL vercel.app.

Jangan commit API key.
